# Kalyan Chitteti Portfolio

Responsive light editorial portfolio for GitHub Pages.

- Initial KC screen with PLAY INTRO / SCROLL TO ENTER / SKIP INTRO
- Generated 9-second animated intro video
- Generated animated showreel placeholder
- Responsive Home / Work / Services / About / Team / Tools / Contact pages
- Team cards expand in place on click/tap
- Replace generated showreel and category media with final videos later
